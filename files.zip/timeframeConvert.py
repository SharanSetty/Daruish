import pandas as pd

def convertData(df:pd.DataFrame, freq):
    volume = []
    for i in range(len(df)//240):
        sum = 0
        for j in range(240):
            sum += df['volume'].iloc[i*j]
        volume.append(sum)
    volume.append(sum)

    return df.groupby(pd.Grouper(freq=freq)).agg({'open':'first', 'high':'max', 'low':'min', 'close':'last'}), volume

data = pd.read_csv('./files/ETHBTC1.csv')
data['datetime'] = pd.to_datetime(data['datetime'])
data = data.set_index('datetime')
#fiveMinData = convertData(data, '5min')
fourHourData, volume = convertData(data, '4H')
for i in range(len(fourHourData) - len(volume)):
    volume.append(0)
fourHourData['volume'] = volume

#fiveMinData.to_csv('fiveMinData.csv')
fourHourData.to_csv('./files/fourHourData.csv')